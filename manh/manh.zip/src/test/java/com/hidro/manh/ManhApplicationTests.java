package com.hidro.manh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManhApplicationTests {

	@Test
	void contextLoads() {
	}

}
