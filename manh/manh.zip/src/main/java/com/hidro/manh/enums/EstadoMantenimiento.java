package com.hidro.manh.enums;

public enum EstadoMantenimiento {
    SI, NO, CB
}
