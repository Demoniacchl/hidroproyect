package com.hidro.manh.rep;

import com.hidro.manh.ety.RegionEty;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegionRep extends JpaRepository<RegionEty, Integer> {
}
