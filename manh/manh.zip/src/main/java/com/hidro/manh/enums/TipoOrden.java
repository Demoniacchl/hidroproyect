package com.hidro.manh.enums;

public enum TipoOrden {
    MANTENIMIENTO, 
    REPARACION,
    PREVENTIVA,
    CORRECTIVA,
    PREDICTIVA,
    EMERGENCIA
}