package com.hidro.manh.enums;

public enum Region {
    ARICA_PARINACOTA,
    TARAPACA,
    ANTOFAGASTA,
    ATACAMA,
    COQUIMBO,
    VALPARAISO,
    METROPOLITANA,
    O_HIGGINS,
    MAULE,
    ÑUBLE,
    BIOBIO,
    ARAUCANIA,
    LOS_RIOS,
    LOS_LAGOS,
    AYSEN,
    MAGALLANES
}
