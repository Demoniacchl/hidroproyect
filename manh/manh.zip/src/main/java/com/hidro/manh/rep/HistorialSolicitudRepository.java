package com.hidro.manh.rep;

import org.springframework.data.jpa.repository.JpaRepository;
import com.hidro.manh.ety.HistorialSolicitud;

public interface HistorialSolicitudRepository extends JpaRepository<HistorialSolicitud, Long> {}
