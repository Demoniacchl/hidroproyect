package com.hidro.manh.dto;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class RegionDto {
    private Integer id;
    private String region;
}
