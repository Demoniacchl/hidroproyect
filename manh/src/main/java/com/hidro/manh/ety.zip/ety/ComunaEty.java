package com.hidro.manh.ety;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "comunas")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ComunaEty {
    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "comuna", nullable = false, length = 250)
    private String comuna;

    @Column(name = "region_id", nullable = false)
    private Integer regionId;
}
