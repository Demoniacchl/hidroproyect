package com.hidro.manh.enums;

public enum EstadoEvento {
    PROGRAMADO,
    EN_PROCESO,
    COMPLETADO,
    CANCELADO
}