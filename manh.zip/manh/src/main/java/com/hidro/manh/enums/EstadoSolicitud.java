package com.hidro.manh.enums;

public enum EstadoSolicitud {
    PENDIENTE,
    EN_GESTION,
    COMPLETADA,
    CANCELADA
}