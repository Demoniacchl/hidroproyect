package com.hidro.manh.enums;

public enum EstadoProgreso {
    PENDIENTE,
    EN_PROCESO,
    COMPLETADO,
    CANCELADO,
    EN_ESPERA
}