package com.hidro.manh.enums;

public enum RolUsuario {
    SUPER_ADMIN,
    ADMIN,
    TECNICO
}
