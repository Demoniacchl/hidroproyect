package com.hidro.manh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManhApplication {

    public static void main(String[] args) {
        SpringApplication.run(ManhApplication.class, args);
    }
}