package com.hidro.manh.enums;

public enum ProgresoReparacion {
    REALIZADO, NO_REALIZADO, EN_GESTION
}
