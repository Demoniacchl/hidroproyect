package com.hidro.manh.enums;

public enum ComunaCoquimbo {
    LA_SERENA,
    COQUIMBO,
    ANDACOLLO,
    VICUÑA,
    OVALLE,
    MONTE_PATRIA,
    COMBARBALA,
    ILLAPEL,
    SALAMANCA,
    LOS_VILOS
}
