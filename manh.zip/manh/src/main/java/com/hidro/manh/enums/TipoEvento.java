package com.hidro.manh.enums;

public enum TipoEvento {
    MANTENCION,
    REPARACION, 
    EMERGENCIA,
    INSTALACION
}